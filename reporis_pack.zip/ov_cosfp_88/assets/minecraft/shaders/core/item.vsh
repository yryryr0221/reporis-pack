#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec4 lightMapColor;
out vec4 overlayColor;

out vec2 texCoord0;
out float ncBack;
out vec3 ncPos;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    // NobleCity: hide my own back cosmetic in first person (vertex color #FFFEFD = owner-only mark, 26.x port of ov_cosfp_330)
    vec3 ncC = Color.rgb * 255.0;
    // color conversion may drop 1, so accept g 252.5-254.5, b 251.5-253.5 (pure white 255,255,255 never matches)
    bool ncMark = ncC.r > 254.5 && ncC.g > 252.5 && ncC.g < 254.5 && ncC.b > 251.5 && ncC.b < 253.5;
    ncBack = (ncMark && ProjMat[2][3] != 0.0) ? 1.0 : 0.0;   // perspective (world) only, not orthographic GUI
    ncPos = Position;
    vec4 ncColor = ncMark ? vec4(1.0, 1.0, 1.0, Color.a) : Color;

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, ncColor);
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);

    texCoord0 = UV0;
}
