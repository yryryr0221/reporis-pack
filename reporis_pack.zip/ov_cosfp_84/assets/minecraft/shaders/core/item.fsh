#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in float ncBack;
in vec3 ncPos;

out vec4 fragColor;

void main() {
    // NobleCity: drop marked fragments within 1.6 blocks horizontally and -2.1..+1.4 vertically of the camera. F5 (4 blocks back) and other players are untouched.
    if (ncBack > 0.5 && length(ncPos.xz) < 1.6 && ncPos.y > -2.1 && ncPos.y < 1.4) {
        discard;
    }
    vec4 color = texture(Sampler0, texCoord0);
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif

    color *= vertexColor * ColorModulator;
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
