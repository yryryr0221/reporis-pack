#version 150

#moj_import <minecraft:fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    // NobleCity money HUD: move boss bar title from top-center to top-left (GUI ortho projection, marked colors only).
    ivec3 nc = ivec3(round(Color.rgb * 255.0));
    if (ProjMat[2][3] == 0.0 && (nc == ivec3(254, 253, 249) || nc == ivec3(63, 63, 62))) {
        gl_Position.x += (-1.0 + 151.0 * ProjMat[0][0]) * gl_Position.w;
    }

    vertexDistance = fog_distance(Position, FogShape);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
