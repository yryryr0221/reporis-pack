#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;


out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec2 texCoord1;
out vec2 texCoord2;
// 노블시티: 등 치장 1인칭 숨기기 (정점 색 #FFFEFD = 등 치장 표지)
out float ncBack;
out vec3 ncPos;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vec3 c = Color.rgb * 255.0;
    // 색 변환에서 1 낮아질 수 있어 g 252.5~254.5, b 251.5~253.5 로 받는다(순수 흰색 255,255,255 는 해당 없음)
    bool mark = c.r > 254.5 && c.g > 252.5 && c.g < 254.5 && c.b > 251.5 && c.b < 253.5;
    ncBack = (mark && ProjMat[2][3] != 0.0) ? 1.0 : 0.0;   // 원근 투영(월드)일 때만, 인벤토리 같은 정투영은 제외
    ncPos = Position;
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, mark ? vec4(1.0, 1.0, 1.0, Color.a) : Color) * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    texCoord1 = UV1;
    texCoord2 = UV2;
}
