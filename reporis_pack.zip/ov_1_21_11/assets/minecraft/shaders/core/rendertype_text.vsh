#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    // 노블시티 자금 HUD: 보스바 제목(화면 위 가운데)을 왼쪽 위로 옮긴다. GUI(직교 투영)에서 이 색 글자만.
    ivec3 nc = ivec3(round(Color.rgb * 255.0));
    if (ProjMat[2][3] == 0.0 && (nc == ivec3(254, 253, 249) || nc == ivec3(63, 63, 62))) {
        gl_Position.x += (-1.0 + 151.0 * ProjMat[0][0]) * gl_Position.w;
    }

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
