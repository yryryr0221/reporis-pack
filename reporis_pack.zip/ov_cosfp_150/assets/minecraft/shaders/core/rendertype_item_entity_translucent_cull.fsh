#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;
in float ncBack;
in vec3 ncPos;

out vec4 fragColor;

void main() {
    // 노블시티: 내 등 치장(카메라 둘레 수평 1.35칸·높이 -1.9~+1.0칸)은 1인칭에서 버림. F5(4칸 뒤)·다른 사람은 그대로.
    if (ncBack > 0.5 && length(ncPos.xz) < 1.35 && ncPos.y > -1.9 && ncPos.y < 1.0) {
        discard;
    }
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
