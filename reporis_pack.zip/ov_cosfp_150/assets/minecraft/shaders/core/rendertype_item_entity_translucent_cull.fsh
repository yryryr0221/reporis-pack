#version 150

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;
in float ncBack;
in vec3 ncPos;

out vec4 fragColor;

void main() {
    // 노블시티: 내 등 치장·신화 이펙트(표지는 내 것에만, 11-22)가 카메라 둘레 수평 1.6칸·높이 -2.1~+1.4칸이면 버림. F5(4칸 뒤)·다른 사람은 그대로.
    if (ncBack > 0.5 && length(ncPos.xz) < 1.6 && ncPos.y > -2.1 && ncPos.y < 1.4) {
        discard;
    }
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
